#' -----------------------------------------------------------------------------
#' title:  "Simulation data set generator for M2PL model"
#' author: "Laixu3107"
#' date:   "2023.11.04"
#' -----------------------------------------------------------------------------

if(sys.nframe() == 0L){rm(list=ls()); gc()}
library(magrittr)
library(MASS)

# ---- Data Generator function -------------------------------------------------
DataGen <- function(A_t, b_t, sigma_t, N, seed_num){
  
  set.seed(seed_num)
  
  J <- ncol(A_t)
  K <- nrow(A_t)
  
  x <- mvrnorm(n=N, mu=rep(0,K), Sigma=sigma_t) # latent traits
  y <- x %>%
    `%*%` (A_t) %>%
    `+` (matrix(data=b_t,nrow=N,ncol=J,byrow=T)) %>%
    plogis(q=.) %>%
    rbinom(n=N*J, size=1, prob=.) %>%
    matrix(data=., nrow=N, ncol=J, byrow=F)
  
  storage.mode(y) <- "integer"
  return(list(y=y,x=x))
}
# ------------------------------------------------------------------------------


# ---- K = 3, 4, 5, 6----
# ---- J = 40 ----
# ---- N = 500, 1000, 2000,4000 ---- 

K_list <- c(3)
N_list <- c(500,1000,2000,4000)

M <- 100  # no. of data set
J <- 40   # no. of items


for(K in K_list){
  for(N in N_list){
    
    load(file=sprintf("../M2PL/TrueParam/TrueParam_K%dJ%d.Rdata",K,J)) # load A_t, b_t,Sigma_t
    
    
    if(!dir.exists(sprintf("../M2PL/Datasets/K%dJ%dN%d_S0_EK0",K,J,N))){
      dir.create(sprintf("../M2PL/Datasets/K%dJ%dN%d_S0_EK0", K,J,N))
    }
    
    # ---- Generate random sample ----
    set.seed(N+K*10)
    seed_vec <- sample(1e6:(1e7-1), M, replace=FALSE)
    
    for(m in 1:M){
      
      cat(sprintf("K:%d, N:%d, m:%d\r", K, N, m))
      seed_num <- seed_vec[m]
      
      output <- DataGen(A_t, b_t, Sigma_t, N, seed_num)
      y <- output$y
      x <- output$x
      
      colnames(x) <- paste("trait", 1:K, sep="")
      colnames(y) <- paste("item", sprintf("%02d", 1:J), sep="")
      
      # ---- save dataset ----
      save(seed_num, A_t, b_t, Sigma_t, y, x,
           file=sprintf("../M2PL/Datasets/K%dJ%dN%d_S0_EK0/K%dJ%dN%d_S0_EK0_dataset%03d.Rdata",
                        K,J,N,K,J,N,m))
      write.csv(y, file=sprintf("../M2PL/Datasets/K%dJ%dN%d_S0_EK0/K%dJ%dN%d_S0_EK0_y%03d.csv",
                                K,J,N,K,J,N,m))
      
    }
    
  }
}


