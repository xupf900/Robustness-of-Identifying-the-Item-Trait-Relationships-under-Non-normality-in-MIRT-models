

rm(list=ls());gc()
source("./02_M2plmEML1_fcn.R")

# ---- setting -----------------------------------------------------------------
K_list <- c(3)
N_list <- c(500,1000,2000,4000)
S_list <- c(2)  

simulations <- 1:100

J <- 40
n_nodes <- 5
gamma <- 0

# ------------------------------------------------------------------------------
for (K in K_list) {
  
  for (N in N_list) {
    
    data_dir <- sprintf("../M2PL/Datasets")
    save_dir <- sprintf("../M2PL/Results_EML1")
    
    for (S in S_list) {
      
      if (S == 0)  {EK_list <- c(0)}
      if (S == -1) {EK_list <- c(0)}
      if (S == 2)  {EK_list <- c(4)}
      
      for (EK in EK_list) {
        
        case_dir <- sprintf("K%dJ%dN%d_S%d_EK%d", K, J, N, S,EK)
        
        if(!dir.exists(sprintf("%s/%s",save_dir,case_dir))){
          dir.create(sprintf("%s/%s",save_dir,case_dir))
        }
        
        load(file=sprintf("../M2PL/TrueParam/TrueParam_K%dJ%d.Rdata",K,J))
        
        if(K==3) fixed <- c(1,10,19)  
        if(K==4) fixed <- c(1,7,13,19)
        if(K==5) fixed <- c(1,5,9,13,17)
        
        if(K==3) eta_list <- (10:1)/200*N
        if(K==4){
          if(N==4000) eta_list <- (10:1)/400*N
          if(N==2000) eta_list <- (10:1)/400*N
          if(N==1000) eta_list <- (10:1)/200*N
          if(N==500)  eta_list <- (10:1)/200*N
        }
        if(K==5){
          if(N==4000) eta_list <- (10:1)/400*N
          if(N==2000) eta_list <- (10:1)/400*N
          if(N==1000) eta_list <- (10:1)/200*N
          if(N==500)  eta_list <- (10:1)/200*N
        }
        
        A_init <- matrix(data=1/J, nrow=K, ncol=J); A_init[,fixed] <- diag(1,K)
        b_init <- rep(0,J)
        c_init <- rep(0.1,J)
        Sigma_init <- diag(1,K)
        
        
        # ------------------------------------------------------------------------
        # -------- simulation ----------------------------------------------------
        # ------------------------------------------------------------------------
        for(simu in simulations){
          
          cat(sprintf("======== K:%d, N:%d,  S:%d,EK:%d, simulation: %03d ======== \t^_^!\n", 
                      K,N,S,EK,simu))
          
          y <- read.csv(file=sprintf("%s/%s/%s_y%03d.csv", data_dir, case_dir, case_dir, simu), row.names=1)
          y <- as.matrix(y)
          
          if(FALSE){M2pl_EML1 <- NULL}
          
          # ---- Calculating ----
          output <- M2pl_EML1_path(
            y = y,           
            A_init = A_init,
            b_init = b_init,
            Sigma_init = Sigma_init,
            eta_list = eta_list,
            fixed = fixed,
            n_nodes = n_nodes,
            
            MaxIter.EM = 100,
            MaxIter.CD = 50,
            Tol.EM = 1e-4,
            Tol.CD = 1e-6,
            reestimate = TRUE,# re-estimate the parameter by EM
            gamma = 0
            
          )
          
          # ---- Resulting ----
          A_opt     <- output$opt_A
          b_opt     <- output$opt_b
          Sigma_opt <- output$opt_Sigma
          eta_opt   <- output$opt_eta
          opt       <- output$opt
          
          time_eml1 <- output$time_total
          path      <- output$path
          
          save(A_t, b_t, Sigma_t, y, fixed,
               A_opt, b_opt, Sigma_opt, eta_opt, opt,
               time_eml1, path,
               file=sprintf("%s/%s/%s_output_%03d.RData", save_dir, case_dir, case_dir, simu)
          )
          
          # ---- Calculate CR ----
          CR <- calcu_CR(A_t, A_opt, fixed, col_swap=F)$CR
          cat(sprintf("==== CR: %.3f ====\n",CR))
          
          out_mat <- matrix(data=NA, nrow=1, ncol=4)
          colnames(out_mat) <- c("simu", "usetime", "CR", "opt")
          
          out_mat[1,] <- c(simu, time_eml1, CR, opt)
          
          write.csv(x=A_opt, file=sprintf("%s/%s/%s_Aopt_%03d.csv", save_dir, case_dir, case_dir, simu))
          
          file_name <- sprintf("%s/%s/%s_result.csv", save_dir, case_dir, case_dir)
          while(TRUE){
            
            tryCatch(
              {
                if(file.exists(file_name)){
                  write.table(x = out_mat, file = file_name, append = T, sep = ",", row.names = F, col.names = F)
                }
                else{
                  write.table(x = out_mat, file = file_name, sep = ",", row.names = F)
                }
                break
              },
              warning = function(w){cat("wait minute.\n")},
              error = function(e){cat("wait minute.\n")}
            )
            Sys.sleep(2)
          }
        }
      }
    }
  }
}  
  
        
    
    
      













