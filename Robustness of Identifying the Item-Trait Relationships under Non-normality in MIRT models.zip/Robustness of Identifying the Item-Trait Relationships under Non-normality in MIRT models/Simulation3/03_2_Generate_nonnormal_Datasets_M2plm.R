
if(sys.nframe() == 0L){rm(list=ls()); gc()}
library(magrittr)
library("covsim")

# ---- Data Generator function -------------------------------------------------
DataGen <- function(A_t, b_t, sigma_t, N, seed_num){
  
  set.seed(seed_num)
  
  J <- ncol(A_t)
  K <- nrow(A_t)
  
  y <- x %>%
    `%*%` (A_t) %>%
    `+` (matrix(data=b_t,nrow=N,ncol=J,byrow=T)) %>%
    plogis(q=.) %>%
    rbinom(n=N*J, size=1, prob=.) %>%
    matrix(data=., nrow=N, ncol=J, byrow=F)
  
  storage.mode(y) <- "integer"
  return(list(y=y))
}
# ------------------------------------------------------------------------------
M <- 100  # no. of data set
J <- 40   # no. of items

S_list <- c(2)  


K_list <- c(3)
N_list <- c(500, 1000, 2000, 4000)
# ------------------------------------------------------------------------------
for (K in K_list) {
  
  sigma_t <- matrix(0.6, K, K)
  diag(sigma_t) <- 1
  
  # --skewness_excesskurtosis_combinations Generator function ---
  generate_skewness_excesskurtosis_combinations <- function(K, S_list, EK_list) {
    combinations <- list()
    for (S in S_list) {
      skewness <- rep(S, K)
      
      if (S == 0)  {EK_list <- c(0)}
      if (S == -1) {EK_list <- c(0)}
      if (S == 2)  {EK_list <- c(4)}
      
      for (EK in EK_list) {
        excesskurtosis <- rep(EK, K)
        combinations[[paste0( "_S", S, "_EK", EK)]] <- list(
          skewness = skewness,
          excesskurtosis = excesskurtosis
        )
      }
    }
    
    return(combinations)
  }
  
  SEK <- generate_skewness_excesskurtosis_combinations(K, S_list, EK_list)
  
  # -------------------------------------------------------------
  dataset_counter <- 1
  
  for (N in N_list) {
    
    load(file=sprintf("../M2PL/TrueParam/TrueParam_K%dJ%d.Rdata",K,J)) # load A_t, b_t,Sigma_t
    
    for (SEK_name in names(SEK)) {
      skewness <- SEK[[SEK_name]]$skewness
      excesskurtosis  <- SEK[[SEK_name]]$excesskurtosis
      
      S <- skewness[1]  
      EK <- excesskurtosis[1] 
      
      if(!dir.exists(sprintf("../M2PL/Datasets/K%dJ%dN%d_S%d_EK%d",K,J,N,S,EK))){
        dir.create(sprintf("../M2PL/Datasets/K%dJ%dN%d_S%d_EK%d", K,J,N,S,EK))
      }
      
      # ---- Generate random sample ----
      set.seed(N+K*10)
      seed_vec <- sample(1e6:(1e7-1), M, replace=FALSE)
      
      for (m in 1:M) {  
        
        cat(sprintf("K:%d, N:%d, S:%d, EK:%d, m:%d\r", K, N, S,EK, m))  
        seed_num <- seed_vec[m]
        
        eg <- rIG(N = N, sigma.target = sigma_t, reps = 1, skewness = skewness, excesskurtosis = excesskurtosis)  
        x <- eg[[1]]
        
        output <- DataGen(A_t, b_t, Sigma_t, N, seed_num)
        y <- output$y
        
        colnames(x) <- paste("trait", 1:K, sep="")
        colnames(y) <- paste("item", sprintf("%02d", 1:J), sep="")
        
        # ---- save dataset ----
        
        save(seed_num, A_t, b_t, Sigma_t, y, x, SEK_name, K, S,EK,
             file = sprintf("../M2PL/Datasets/K%dJ%dN%d_S%d_EK%d/K%dJ%dN%d_S%d_EK%d_dataset%03d.Rdata",
                            K,J,N,S,EK,K,J,N,S,EK,m))
        write.csv(y, file=sprintf("../M2PL/Datasets/K%dJ%dN%d_S%d_EK%d/K%dJ%dN%d_S%d_EK%d_y%03d.csv",
                                  K,J,N,S,EK,K,J,N,S,EK,m))
        dataset_counter <- dataset_counter + 1
      }
    }
  }
}           