#' -----------------------------------------------------------------------------
#' title:  "True parameters for M2PL model"
#' author: "Laixu3107"
#' date:   "2023.11.04"
#' -----------------------------------------------------------------------------



# ---- K = 3, J = 40 ----
if(sys.nframe() == 0L){rm(list=ls()); gc()}
Mod_t <- matrix(data=0, nrow=3, ncol=40)
Mod_t[1,c(1:9,28:33,37:40)] <- 1
Mod_t[2,c(10:18,28:30,34:40)] <- 1
Mod_t[3,c(19:27,31:40)] <- 1

set.seed(2310013)
a <- runif(n=sum(Mod_t),0.5,2)
A_t <- matrix(data=0, nrow=3, ncol=40)
A_t[Mod_t==1] <- round(a,3)

A_t[1,1:9]   <- A_t[1,order(A_t[1,1:9],  decreasing=T)]
A_t[2,10:18] <- A_t[2,order(A_t[2,10:18],decreasing=T)+9]
A_t[3,19:27] <- A_t[3,order(A_t[3,19:27],decreasing=T)+18]

A_t[,28:30] <- A_t[,order(colSums(A_t[,28:30]),decreasing=T)+27]
A_t[,31:33] <- A_t[,order(colSums(A_t[,31:33]),decreasing=T)+30]
A_t[,34:36] <- A_t[,order(colSums(A_t[,34:36]),decreasing=T)+33]
A_t[,37:40] <- A_t[,order(colSums(A_t[,37:40]),decreasing=T)+36]

rownames(A_t) <- paste("trait", 1:3, sep="")
colnames(A_t) <- paste("item", sprintf("%02d", 1:40), sep="")


b_t <- round(rnorm(40),3)
Sigma_t <- matrix(0.6,3,3)
diag(Sigma_t) <- 1

save(A_t, b_t, Sigma_t, file="../M2PL/TrueParam/TrueParam_K3J40.Rdata")


# ---- K = 4, J = 40 ----
if(sys.nframe() == 0L){rm(list=ls()); gc()}
Mod_t <- matrix(data=0, nrow=4, ncol=40)
Mod_t[1,c(1:6,25:30,37:39)] <- 1
Mod_t[2,c(7:12,25:26,31:34,37:38,40)] <- 1
Mod_t[3,c(13:18,27:28,31:32,35:37,39:40)] <- 1
Mod_t[4,c(19:24,29:30,33:36,38:40)] <- 1

set.seed(2310014)
a <- runif(n=sum(Mod_t),0.5,2)
A_t <- matrix(data=0, nrow=4, ncol=40)
A_t[Mod_t==1] <- round(a,3)

A_t[1,1:6] <- A_t[1,order(A_t[1,1:6],decreasing=T)]
A_t[2,7:12] <- A_t[2,order(A_t[2,7:12],decreasing=T)+6]
A_t[3,13:18] <- A_t[3,order(A_t[3,13:18],decreasing=T)+12]
A_t[4,19:24] <- A_t[4,order(A_t[4,19:24],decreasing=T)+18]

A_t[,25:26] <- A_t[,order(colSums(A_t[,25:26]),decreasing=T)+24]
A_t[,27:28] <- A_t[,order(colSums(A_t[,27:28]),decreasing=T)+26]
A_t[,29:30] <- A_t[,order(colSums(A_t[,29:30]),decreasing=T)+28]
A_t[,31:32] <- A_t[,order(colSums(A_t[,31:32]),decreasing=T)+30]
A_t[,33:34] <- A_t[,order(colSums(A_t[,33:34]),decreasing=T)+32]
A_t[,35:36] <- A_t[,order(colSums(A_t[,35:36]),decreasing=T)+34]

rownames(A_t) <- paste("trait", 1:4, sep="")
colnames(A_t) <- paste("item", sprintf("%02d", 1:40), sep="")

b_t <- round(rnorm(40),3)
Sigma_t <- matrix(0.6,4,4)
diag(Sigma_t) <- 1

save(A_t, b_t, Sigma_t, file="../M2PL/TrueParam/TrueParam_K4J40.Rdata")


# ---- K = 5, J = 40 ----
if(sys.nframe() == 0L){rm(list=ls()); gc()}
Mod_t <- matrix(data=0, nrow=5, ncol=40)
Mod_t[1,c(1:4,21:24,31:36)] <- 1
Mod_t[2,c(5:8,21,25:27,31:33,37:39)] <- 1
Mod_t[3,c(9:12,22,25,28:29,31,34:35,37:38,40)] <- 1
Mod_t[4,c(13:16,23,26,28,30,32,34,36:37,39:40)] <- 1
Mod_t[5,c(17:20,24,27,29:30,33,35:36,38:40)] <- 1

set.seed(2310015)
a <- runif(n=sum(Mod_t),0.5,2)
A_t <- matrix(data=0, nrow=5, ncol=40)
A_t[Mod_t==1] <- round(a,3)

A_t[1,1:4] <- A_t[1,order(A_t[1,1:4],decreasing=T)]
A_t[2,5:8] <- A_t[2,order(A_t[2,5:8],decreasing=T)+4]
A_t[3,9:12] <- A_t[3,order(A_t[3,9:12],decreasing=T)+8]
A_t[4,13:16] <- A_t[4,order(A_t[4,13:16],decreasing=T)+12]
A_t[5,17:20] <- A_t[5,order(A_t[5,17:20],decreasing=T)+16]

rownames(A_t) <- paste("trait", 1:5, sep="")
colnames(A_t) <- paste("item", sprintf("%02d", 1:40), sep="")

b_t <- round(rnorm(40),3)
Sigma_t <- matrix(0.6,5,5)
diag(Sigma_t) <- 1

save(A_t, b_t, Sigma_t, file="../M2PL/TrueParam/TrueParam_K5J40.Rdata")


# ---- K = 6, J = 40 ----
if(sys.nframe() == 0L){rm(list=ls()); gc()}
Mod_t <- matrix(data=0, nrow=6, ncol=40)
Mod_t[1,c(1:4,25:28,37:38)] <- 1
Mod_t[2,c(5:8,25,29:31,37,39)] <- 1
Mod_t[3,c(9:12,26,29,32:33,38,40)] <- 1
Mod_t[4,c(13:16,27,30,34:35,37,39)] <- 1
Mod_t[5,c(17:20,28,32,34,36,39:40)] <- 1
Mod_t[6,c(21:24,31,33,35:36,38,40)] <- 1

set.seed(2310016)
a <- runif(n=sum(Mod_t),0.5,2)
A_t <- matrix(data=0, nrow=6, ncol=40)
A_t[Mod_t==1] <- round(a,3)

A_t[1,1:4] <- A_t[1,order(A_t[1,1:4],decreasing=T)]
A_t[2,5:8] <- A_t[2,order(A_t[2,5:8],decreasing=T)+4]
A_t[3,9:12] <- A_t[3,order(A_t[3,9:12],decreasing=T)+8]
A_t[4,13:16] <- A_t[4,order(A_t[4,13:16],decreasing=T)+12]
A_t[5,17:20] <- A_t[5,order(A_t[5,17:20],decreasing=T)+16]
A_t[6,21:24] <- A_t[6,order(A_t[6,21:24],decreasing=T)+20]

rownames(A_t) <- paste("trait", 1:6, sep="")
colnames(A_t) <- paste("item", sprintf("%02d", 1:40), sep="")

b_t <- round(rnorm(40),3)
Sigma_t <- matrix(0.6,6,6)
diag(Sigma_t) <- 1

save(A_t, b_t, Sigma_t, file="../M2PL/TrueParam/TrueParam_K6J40.Rdata")

