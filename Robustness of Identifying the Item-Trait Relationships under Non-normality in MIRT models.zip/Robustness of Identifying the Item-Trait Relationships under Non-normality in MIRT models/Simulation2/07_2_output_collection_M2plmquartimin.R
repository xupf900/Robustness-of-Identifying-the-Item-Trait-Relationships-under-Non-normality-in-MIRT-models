

rm(list=ls());  gc()
source("./01_M2plmEMS_fcn.R")
library(magrittr)

# ---- settings ----------------------------------------------------------------
method <- "quartimin"
simu_dir <- "../M2PL"

K_list <- c(3,5)
N_list <- c(500,1000,2000,4000)

M <- 100
J <- 40


# ------------------------------------------------------------------------------
# 新增分类指标计算函数
calculate_classification_metrics <- function(A_t, A_opt, fixed = NULL, col_swap = FALSE) {
  #' 计算分类指标：F1-score, TPR, FPR
  #' 
  #' @param A_t 真实载荷矩阵
  #' @param A_opt 估计载荷矩阵  
  #' @param fixed 固定指标列
  #' @param col_swap 是否进行列交换
  
  # 处理固定列
  if (!is.null(fixed)) {
    A_t <- A_t[, -fixed]
    A_opt <- A_opt[, -fixed]
  }
  
  # 如果需要列交换，找到最佳排列
  if (col_swap) {
    K <- nrow(A_t)
    all_permu <- gtools::permutations(K, K, 1:K)
    best_metrics <- list(F1 = 0, TPR = 0, FPR = 1)
    best_permu <- 1:K
    
    for (i in 1:nrow(all_permu)) {
      A_opt_permuted <- A_opt[all_permu[i, ], ]
      metrics <- calculate_metrics_single(A_t, A_opt_permuted)
      
      if (metrics$F1 > best_metrics$F1) {
        best_metrics <- metrics
        best_permu <- all_permu[i, ]
      }
    }
    
    return(c(best_metrics, list(permu = best_permu)))
  } else {
    metrics <- calculate_metrics_single(A_t, A_opt)
    return(c(metrics, list(permu = 1:nrow(A_t))))
  }
}

calculate_metrics_single <- function(A_t, A_opt) {
  #' 计算单个矩阵对的分类指标
  
  # 创建二进制矩阵（非零=1，零=0）
  A_t_binary <- (A_t != 0) * 1
  A_opt_binary <- (A_opt != 0) * 1
  
  # 计算混淆矩阵
  TP <- sum((A_t_binary == 1) & (A_opt_binary == 1))  # 真实为非零，估计为非零
  FP <- sum((A_t_binary == 0) & (A_opt_binary == 1))  # 真实为零，估计为非零
  TN <- sum((A_t_binary == 0) & (A_opt_binary == 0))  # 真实为零，估计为零
  FN <- sum((A_t_binary == 1) & (A_opt_binary == 0))  # 真实为非零，估计为零
  
  # 计算指标
  Precision <- ifelse((TP + FP) > 0, TP / (TP + FP), 0)
  Recall <- TPR <- ifelse((TP + FN) > 0, TP / (TP + FN), 0)
  FPR <- ifelse((FP + TN) > 0, FP / (FP + TN), 0)
  F1 <- ifelse((Precision + Recall) > 0, 2 * Precision * Recall / (Precision + Recall), 0)
  
  # 返回结果
  return(list(
    TP = TP, FP = FP, TN = TN, FN = FN,
    Precision = Precision,
    Recall = Recall,
    TPR = TPR,
    FPR = FPR,
    F1 = F1
  ))
}

# ------------------------------------------------------------------------------
for(K in K_list){
  
  if (K == 3) {non_values <- c("0", "1", "2", "3")}
  if (K == 4) {non_values <- c("0", "1", "2", "3", "4")}
  if (K == 5) {non_values <- c("0", "1", "2", "3", "4", "5")}
  
  for(N in N_list){
    
    resu_dir <- sprintf("%s/Results_%s", simu_dir, method)
    
    for (non_str in non_values) {
      case_dir <- sprintf("K%dJ%dN%d_non%s", K, J, N, non_str)  
      
      cat(sprintf("K: %d, N: %04d, non:%s.\n", K, N,non_str))
      
      # ---- load true parameters ----
      load(file=sprintf("%s/TrueParam/TrueParam_K%dJ%d.Rdata", simu_dir, K, J))
      
      if(K==3) fixed <- c(1,10,19)
      if(K==4) fixed <- c(1,7,13,19)
      if(K==5) fixed <- c(1,5,9,13,17)
      
      # ---- Collect result for esch simulation ----
      cpu.total.vec <- rep(0,M)
      iter.vec <- rep(0,M)
      CR.vec   <- rep(0,M)
      
      # 新增分类指标向量
      F1.vec <- rep(0,M)
      TPR.vec <- rep(0,M)
      FPR.vec <- rep(0,M)
      Precision.vec <- rep(0,M)
      Recall.vec <- rep(0,M)
      
      A_opt_list <- list()
      b_opt_list <- list()
      S_opt_list <- list()
      
      
      for(simu in 1:M){
        
        filepath <- sprintf("%s/%s/%s_output_%03d.Rdata", resu_dir, case_dir, case_dir, simu)
        
        load(file=filepath)
        
        # -- cpu time & CR-- 
        iter.vec[simu] <- iter_ems
        cpu.total.vec[simu] <- time_ems
        CR.vec[simu] <- calcu_CR(A_t, A_cut, fixed, col_swap=F)$CR
        
        # -- 新增分类指标计算 --
        metrics <- calculate_classification_metrics(A_t, A_cut, fixed, col_swap = F)
        F1.vec[simu] <- metrics$F1
        TPR.vec[simu] <- metrics$TPR
        FPR.vec[simu] <- metrics$FPR
        Precision.vec[simu] <- metrics$Precision
        Recall.vec[simu] <- metrics$Recall
        
        # -- Aopt_list, bopt_list, Sopt_list --
        A_opt_list[[simu]] <- A_cut
        b_opt_list[[simu]] <- b_opt
        S_opt_list[[simu]] <- Sigma_opt
      }
      
      
      # ---- MSE of A ----
      MSEA.vec <- A_opt_list %>%
        lapply(X=., FUN=function(x,y){(x-y)^2}, y=A_t) %>% 
        Reduce("+", .) %>% 
        "/" (M) %>% 
        as.vector()
      
      
      # ---- MSE of b ----
      MSEb.vec <- b_opt_list %>%
        lapply(X=., FUN=function(x,y){(x-y)^2}, y=b_t) %>% 
        Reduce("+", .) %>% 
        "/" (M)
      
      # ---- MSE of Sigma----
      MSES <- S_opt_list %>%
        lapply(X=., FUN=function(x,y){(x-y)^2}, y=Sigma_t) %>%
        Reduce("+", .) %>%
        "/" (M)
      
      MSES.vec <- as.vector(MSES[lower.tri(MSES)])
      
      
      # ---- Bias of A ----
      BiasA.vec <- A_opt_list %>%
        lapply(X=., FUN=function(x,y){x-y}, y=A_t) %>% 
        Reduce("+", .) %>% 
        "/" (M) %>% 
        as.vector()
      
      
      # ---- Bias of b ----
      Biasb.vec <- b_opt_list %>%
        lapply(X=., FUN=function(x,y){(x-y)}, y=b_t) %>% 
        Reduce("+", .) %>% 
        "/" (M)
      
      # ---- Bias of Sigma----
      BiasS <- S_opt_list %>%
        lapply(X=., FUN=function(x,y){(x-y)}, y=Sigma_t) %>%
        Reduce("+", .) %>%
        "/" (M)
      
      BiasS.vec <- as.vector(BiasS[lower.tri(BiasS)])
      
      
      
      # -- save result --
      save(A_opt_list, b_opt_list, S_opt_list,
           MSEA.vec, MSEb.vec, MSES.vec,
           BiasA.vec, Biasb.vec, BiasS.vec,
           CR.vec, F1.vec, TPR.vec, FPR.vec, Precision.vec, Recall.vec, # 新增分类指标
           iter.vec, cpu.total.vec,
           file = sprintf("%s/%s_RESULTS.RData", resu_dir, case_dir))
      
      
    }
  }
}





    

    

    
   