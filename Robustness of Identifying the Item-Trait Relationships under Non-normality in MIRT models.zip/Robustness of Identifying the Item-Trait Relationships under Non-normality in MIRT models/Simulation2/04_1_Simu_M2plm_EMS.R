

rm(list=ls());gc()
source("./01_M2plmEMS_fcn.R")

# ---- setting -----------------------------------------------------------------
K_list <- c(3,5)
N_list <- c(500,1000,2000,4000)

simulations <- 1:100

J <- 40
n_nodes <- 5
gamma_list <- c(0)

# -----------------------------------  -------------------------------------------
for (K in K_list) {
  
  if (K == 3) {non_values <- c("0", "1", "2", "3")}
  if (K == 4) {non_values <- c("0", "1", "2", "3", "4")}
  if (K == 5) {non_values <- c("0", "1", "2", "3", "4", "5")}
  if (K == 6) {non_values <- c("0", "1", "2", "3", "4", "5", "6")}
  
  for (N in N_list) {
    
    for (gamma in gamma_list) {
      
      data_dir <- sprintf("../M2PL/Datasets")
      if(gamma == 0)  {save_dir <- sprintf("../M2PL/Results_EMS")}
      if(gamma == 0.5){save_dir <- sprintf("../M2PL/Results_EMS_tau05")}
      if(gamma == 1)  {save_dir <- sprintf("../M2PL/Results_EMS_tau1")}
      
      for (non_str in non_values) {
        case_dir <- sprintf("K%dJ%dN%d_non%s", K, J, N, non_str)
        
        if(!dir.exists(sprintf("%s/%s",save_dir,case_dir))){
          dir.create(sprintf("%s/%s",save_dir,case_dir))
        }
        
        
        load(file=sprintf("../M2PL/TrueParam/TrueParam_K%dJ%d.Rdata",K,J))
        
        if(K==3) fixed <- c(1,10,19)  
        if(K==4) fixed <- c(1,7,13,19)
        if(K==5) fixed <- c(1,5,9,13,17)
        if(K==6) fixed <- c(1,5,9,13,17,21)
        
        
        
        if(K == 3 & N ==  500){ a_init <- 1/J }
        if(K == 3 & N == 1000){ a_init <- 1/J }
        if(K == 3 & N == 2000){ a_init <- 1/J }
        if(K == 3 & N == 4000){ a_init <- 1/J }
        if(K == 4 & N ==  500){ a_init <- 1/J }
        if(K == 4 & N == 1000){ a_init <- 1/J }
        if(K == 4 & N == 2000){ a_init <- 1/J }
        if(K == 4 & N == 4000){ a_init <- 1/J }
        if(K == 5 & N ==  500){ a_init <- 1/J }
        if(K == 5 & N == 1000){ a_init <- 1/J }
        if(K == 5 & N == 2000){ a_init <- 1/J }
        if(K == 5 & N == 4000){ a_init <- 1/J }
        if(K == 6 & N ==  500){ a_init <- 1/J }
        if(K == 6 & N == 1000){ a_init <- 1/J }
        if(K == 6 & N == 2000){ a_init <- 1/J }
        if(K == 6 & N == 4000){ a_init <- 1/J }
        
        A_init <- matrix(data=a_init, nrow=K, ncol=J); A_init[,fixed] <- diag(1,K)
        b_init <- rep(0,J)
        Sigma_init <- diag(1,K)
        
        
        # ----------------------------------------------------------------------
        # -------- simulation --------------------------------------------------
        # ----------------------------------------------------------------------
        for(simu in simulations){
          
          cat(sprintf("=== K:%d, N:%d, non:%s,simulation: %03d === \t^_^!\n",
                      K,N,non_str,simu))
          
          y <- read.csv(file=sprintf("%s/%s/%s_y%03d.csv", data_dir, case_dir, case_dir, simu), row.names=1)
          y <- as.matrix(y)
          
          if(FALSE){M2pl_EMS <- NULL}
          
          # ---- Calculating ----
          output <- M2pl_EMS(y = y,           
                             A_init = A_init,
                             b_init = b_init,
                             Sigma_init = Sigma_init,
                             beta_list = NULL,
                             fixed = fixed,
                             
                             n_nodes = n_nodes,      # number of quadrature points per dimension
                             gamma = gamma,
                             
                             is.sigmaknown  = 0,
                             MaxIter.EMS    = 50,
                             MaxIter.Newton = 50,
                             Tol.para   = 1e-3,
                             Tol.qfcn   = 1e-4,
                             Tol.newton = 1e-4
                             
          )
          
          # ---- Resulting ----
          A_opt     <- output$A_opt
          b_opt     <- output$b_opt
          Sigma_opt <- output$Sigma_opt # modified in 2023.10.04
          
          qfcn_seq  <-  output$qfcn_seq
          qtt_seq   <-  output$qtt_seq
          iter_ems  <-  output$iter_ems
          time_ems  <-  output$time_ems
          obs_ebic  <-  output$obs_ebic
          all_cpu_time <-  output$all_cpu_time
          
          save(A_t, b_t, Sigma_t, y, fixed,
               A_opt, b_opt, Sigma_opt,
               qfcn_seq, qtt_seq,
               iter_ems, time_ems, obs_ebic, all_cpu_time,
               file=sprintf("%s/%s/%s_output_%03d.RData", save_dir, case_dir, case_dir, simu)
          )
          
          # ---- Calculate CR ----
          CR <- calcu_CR(A_t, A_opt, fixed, col_swap=F)$CR
          cat("CR:",CR,"\n")
          out_mat <- matrix(data=NA, nrow=1, ncol=3)
          colnames(out_mat) <- c("simu", "usetime", "CR")
          
          out_mat[1,] <- c(simu, time_ems, CR)
          
          write.csv(x=A_opt, file=sprintf("%s/%s/%s_Aopt_%03d.csv", save_dir, case_dir, case_dir, simu))
          
          file_name <- sprintf("%s/%s/%s_result.csv", save_dir, case_dir, case_dir)
          while(TRUE){
            
            tryCatch(
              {
                if(file.exists(file_name)){
                  write.table(x = out_mat, file = file_name, append = T, sep = ",", row.names = F, col.names = F)
                }
                else{
                  write.table(x = out_mat, file = file_name, sep = ",", row.names = F)
                }
                break
              },
              warning = function(w){cat("wait minute.\n")},
              error = function(e){cat("wait minute.\n")}
            )
            Sys.sleep(2)
          }
        }
      }
    }
  }  
}      
      
      



