

rm(list=ls());gc()
source("./01_M2plmEMS_fcn.R")
library(GPArotation)

# ---- setting -----------------------------------------------------------------
K_list <- c(3,5)
N_list <- c(500,1000,2000,4000)

simulations <- 1:100

J <- 40
n_nodes <- 5
gamma <- 0

# ------------------------------------------------------------------------------
for (K in K_list) {
  
  if (K == 3) {non_values <- c("0", "1", "2", "3")}
  if (K == 4) {non_values <- c("0", "1", "2", "3", "4")}
  if (K == 5) {non_values <- c("0", "1", "2", "3", "4", "5")}
  
  for (N in N_list) {
    
    data_dir <- sprintf("../M2PL/Datasets")
    save_dir <- sprintf("../M2PL/Results_quartimin")  
    
    for (non_str in non_values) {
      case_dir <- sprintf("K%dJ%dN%d_non%s", K, J, N, non_str)
      
      if(!dir.exists(sprintf("%s/%s",save_dir,case_dir))){
        dir.create(sprintf("%s/%s",save_dir,case_dir))
      }
      
      load(file=sprintf("../M2PL/TrueParam/TrueParam_K%dJ%d.Rdata",K,J))
      
      fixed <- 1:J
      
      set.seed(20231021)
      A_init <- matrix(1/J + runif(K*J, -0.1/J, 0.1/J), K, J)
      b_init <- rep(0,J)
      Sigma_init <- diag(1,K)
      
      
      # ------------------------------------------------------------------------
      # -------- simulation ----------------------------------------------------
      # ------------------------------------------------------------------------
      for(simu in simulations){
        
        cat(sprintf("======== K:%d, N:%d, non:%s, simulation: %03d ======== \t^_^!\n", 
                    K,N,non_str,simu))
        
        y <- read.csv(file=sprintf("%s/%s/%s_y%03d.csv", data_dir, case_dir, case_dir, simu), row.names=1)
        y <- as.matrix(y)
        
        if(FALSE){M2pl_EMS <- NULL}
        
        # ---- Calculating ----
        output <- M2pl_EMS(y = y,           
                           A_init = A_init,
                           b_init = b_init,
                           Sigma_init = Sigma_init,
                           beta_list = NULL,
                           fixed = 1:J,
                           
                           n_nodes = n_nodes,      
                           gamma = gamma,
                           
                           is.sigmaknown  = 1,
                           MaxIter.EMS    = 50,
                           MaxIter.Newton = 50,
                           Tol.para   = 1e-3,
                           Tol.qfcn   = 1e-4,
                           Tol.newton = 1e-4
                           
        )
        
        # ---- Resulting ----
        A_opt     <- output$A_opt
        b_opt     <- output$b_opt
        Sigma_opt <- output$Sigma_opt # modified in 2023.10.04
        
        qfcn_seq  <-  output$qfcn_seq
        qtt_seq   <-  output$qtt_seq
        iter_ems  <-  output$iter_ems
        time_ems  <-  output$time_ems
        obs_ebic  <-  output$obs_ebic
        all_cpu_time <-  output$all_cpu_time
        
        # ---- rotation & cutoff ----
        output_rot <- quartimin(t(output$A_opt), normalize=T, eps=1e-4)
        A_rot <- t(output_rot$loadings)
        S_rot <- output_rot$Phi
        
        A_cut <- A_rot
        A_cut[abs(A_rot)<0.30] <- 0
        
        CR_and_permu <- calcu_CR(A_t, A_cut, fixed=NULL, col_swap=TRUE)
        CR    <- CR_and_permu$CR
        permu <- CR_and_permu$permu
        
        A_rot <- A_rot[permu,]
        A_cut <- A_cut[permu,]
        S_rot <- S_rot[permu,permu]
        
        # ---- save output ----
        save(A_t, b_t, Sigma_t, y,
             A_opt, b_opt, Sigma_opt, A_rot, S_rot, A_cut,
             qfcn_seq, qtt_seq,
             iter_ems, time_ems, obs_ebic, all_cpu_time,
             file=sprintf("%s/%s/%s_output_%03d.RData", save_dir, case_dir, case_dir, simu)
        )
        
        out_mat <- matrix(data=NA, nrow=1, ncol=3)
        colnames(out_mat) <- c("simu", "usetime", "CR")
        
        out_mat[1,] <- c(simu, time_ems, CR)
        
        write.csv(x=A_cut, file=sprintf("%s/%s/%s_Aopt_%03d.csv", save_dir, case_dir, case_dir, simu))
        
        file_name <- sprintf("%s/%s/%s_result.csv", save_dir, case_dir, case_dir)
        while(TRUE){
          
          tryCatch(
            {
              if(file.exists(file_name)){
                write.table(x = out_mat, file = file_name, append = T, sep = ",", row.names = F, col.names = F)
              }
              else{
                write.table(x = out_mat, file = file_name, sep = ",", row.names = F)
              }
              break
            },
            warning = function(w){cat("wait minute.\n")},
            error = function(e){cat("wait minute.\n")}
          )
          Sys.sleep(2)
        }
      }
    }
  }
}    










