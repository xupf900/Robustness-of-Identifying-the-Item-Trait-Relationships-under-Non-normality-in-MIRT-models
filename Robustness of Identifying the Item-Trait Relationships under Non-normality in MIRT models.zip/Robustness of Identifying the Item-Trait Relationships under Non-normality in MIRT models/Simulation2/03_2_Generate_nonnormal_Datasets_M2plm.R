
if(sys.nframe() == 0L){rm(list=ls()); gc()}
library(magrittr)
library("covsim")

# ---- Data Generator function -------------------------------------------------
DataGen <- function(A_t, b_t, sigma_t, N, seed_num){
  
  set.seed(seed_num)
  
  J <- ncol(A_t)
  K <- nrow(A_t)
  
  y <- x %>%
    `%*%` (A_t) %>%
    `+` (matrix(data=b_t,nrow=N,ncol=J,byrow=T)) %>%
    plogis(q=.) %>%
    rbinom(n=N*J, size=1, prob=.) %>%
    matrix(data=., nrow=N, ncol=J, byrow=F)
  
  storage.mode(y) <- "integer"
  return(list(y=y))
}
# ------------------------------------------------------------------------------
M <- 100  # no. of data set
J <- 40   # no. of items

S <- 2
EK <- 4

K_list <- c(3,5)
N_list <- c(500, 1000, 2000, 4000)
# ------------------------------------------------------------------------------
for (K in K_list) {
  
  sigma_t <- matrix(0.4, K, K)
  diag(sigma_t) <- 1
  
  # --skewness_excesskurtosis_combinations Generator function ---
  generate_skewness_excesskurtosis_combinations <- function(K) {
    combinations <- list()
    for (i in 1:K) {
      combinations[[paste0("non", i)]] <- list(
        skewness = c(rep(S, i), rep(0, K - i)),
        excesskurtosis = c(rep(EK, i), rep(0, K - i))
      )
    }
    return(combinations)
  }
  
  SEK <- generate_skewness_excesskurtosis_combinations(K)
  
  # -------------------------------------------------------------
  dataset_counter <- 1
  
  for (N in N_list) {
    
    load(file=sprintf("../M2PL/TrueParam/TrueParam_K%dJ%d.Rdata",K,J)) # load A_t, b_t,Sigma_t
    
    for (non_name in names(SEK)) {
      skewness <- SEK[[non_name]]$skewness
      excesskurtosis  <- SEK[[non_name]]$excesskurtosis  
      
      if(!dir.exists(sprintf("../M2PL/Datasets/K%dJ%dN%d_%s",K,J,N,non_name))){
        dir.create(sprintf("../M2PL/Datasets/K%dJ%dN%d_%s", K,J,N,non_name))
      }
      
      # ---- Generate random sample ----
      set.seed(N+K*10)
      seed_vec <- sample(1e6:(1e7-1), M, replace=FALSE)
      
      for (m in 1:M) {  
        
        cat(sprintf("K:%d, N:%d, non_name:%s, m:%d\r", K, N, non_name, m))  
        seed_num <- seed_vec[m]
        
        eg <- rIG(N = N, sigma.target = sigma_t, reps = 1, skewness = skewness, excesskurtosis = excesskurtosis)  
        x <- eg[[1]]
        
        output <- DataGen(A_t, b_t, Sigma_t, N, seed_num)
        y <- output$y
        
        colnames(x) <- paste("trait", 1:K, sep="")
        colnames(y) <- paste("item", sprintf("%02d", 1:J), sep="")
        
        # ---- save dataset ----
        
        save(seed_num, A_t, b_t, Sigma_t, y, x, SEK, K, non_name,
             file = sprintf("../M2PL/Datasets/K%dJ%dN%d_%s/K%dJ%dN%d_%s_dataset%03d.Rdata",
                            K,J,N,non_name,K,J,N,non_name,m))
        write.csv(y, file=sprintf("../M2PL/Datasets/K%dJ%dN%d_%s/K%dJ%dN%d_%s_y%03d.csv",
                                  K,J,N,non_name,K,J,N,non_name,m))
        dataset_counter <- dataset_counter + 1
      }
    }
  }
}           

  
  


